import React, { useState, useEffect, useMemo } from 'react';
import { Trophy, CalendarDays, Users, PlayCircle, FastForward, Shield, ArrowRight, DollarSign, Shirt } from 'lucide-react';
import { TEAMS, DEFAULT_STARTING_SQUAD, TRANSFER_MARKET_DB } from './constants';
import { generateSchedule, initializeStandings, simulateMatch, updateStandings } from './engine';
import { Match, LeagueStanding, Team, Player, MyPlayer, MatchEvent } from './types';

export default function App() {
  const [gameState, setGameState] = useState<'SETUP' | 'DASHBOARD' | 'MATCH'>('SETUP');
  const [myTeamId, setMyTeamId] = useState<string | null>(null);
  const [currentWeek, setCurrentWeek] = useState(1);
  const [schedule, setSchedule] = useState<Match[]>([]);
  const [standings, setStandings] = useState<LeagueStanding[]>([]);
  const [playedMatch, setPlayedMatch] = useState<Match | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [autoOrganizing, setAutoOrganizing] = useState(false);
  
  // New States for Squad & Transfers
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'SQUAD' | 'TRANSFERS'>('OVERVIEW');
  const [budget, setBudget] = useState(50000000); // 50 Million starting budget
  const [mySquad, setMySquad] = useState<MyPlayer[]>([]);
  const [marketPlayers, setMarketPlayers] = useState<Player[]>([]);
  const [selectedSwapPlayer, setSelectedSwapPlayer] = useState<string | null>(null);

  // Calculate my team's effective rating
  const myEffectiveRating = useMemo(() => {
    const starters = mySquad.filter(p => p.isStarting);
    if (starters.length === 0) return TEAMS.find(t => t.id === myTeamId)?.rating || 70;
    const avg = starters.reduce((sum, p) => sum + p.rating, 0) / starters.length;
    return Math.round(avg);
  }, [mySquad, myTeamId]);
  
  const autoOptimizeSquad = () => {
    setAutoOrganizing(true);
    setTimeout(() => {
      setMySquad(prev => {
        const newSquad = [...prev];
        // Sort by rating desc
        newSquad.sort((a, b) => b.rating - a.rating);
        
        let gks = newSquad.filter(p => p.position === 'GK');
        let outfield = newSquad.filter(p => p.position !== 'GK');
        
        if (gks.length === 0) return prev; // Safe fallback
        
        const bestGk = gks[0]; // Take top GK
        const bestOutfield = outfield.slice(0, 10); // Take top 10 outfield players
        
        const startingIds = new Set([bestGk.id, ...bestOutfield.map(p => p.id)]);
        
        return newSquad.map(p => ({
          ...p,
          isStarting: startingIds.has(p.id)
        }));
      });
      setAutoOrganizing(false);
    }, 1500);
  };
  
  // Initialize league when team is selected
  const handleSelectTeam = (teamId: string) => {
    setMyTeamId(teamId);
    setSchedule(generateSchedule(TEAMS));
    setStandings(initializeStandings(TEAMS));
    setCurrentWeek(1);
    
    // Initialize squad
    const initialSquad: MyPlayer[] = DEFAULT_STARTING_SQUAD.map((p, idx) => ({
      ...p,
      isStarting: idx < 11 // First 11 are starters
    }));
    setMySquad(initialSquad);
    setMarketPlayers([...TRANSFER_MARKET_DB]);
    setBudget(50000000);
    setActiveTab('OVERVIEW');
    
    setGameState('DASHBOARD');
  };

  const handlePlayerClick = (playerId: string) => {
    if (!selectedSwapPlayer) {
      setSelectedSwapPlayer(playerId);
      return;
    }

    if (selectedSwapPlayer === playerId) {
      setSelectedSwapPlayer(null);
      return;
    }

    const player1 = mySquad.find(p => p.id === selectedSwapPlayer)!;
    const player2 = mySquad.find(p => p.id === playerId)!;

    if (player1.isStarting !== player2.isStarting) {
      setMySquad(prev => prev.map(p => {
        if (p.id === player1.id) return { ...p, isStarting: player2.isStarting };
        if (p.id === player2.id) return { ...p, isStarting: player1.isStarting };
        return p;
      }));
      setSelectedSwapPlayer(null);
    } else {
      setSelectedSwapPlayer(playerId);
    }
  };

  const buyPlayer = (player: Player) => {
    if (budget >= player.price) {
      setBudget(prev => prev - player.price);
      setMarketPlayers(prev => prev.filter(p => p.id !== player.id));
      setMySquad(prev => [...prev, { ...player, isStarting: false }]);
    } else {
      alert('ميزانيتك لا تكفي لشراء هذا اللاعب.');
    }
  };

  const formatMoney = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'EUR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(amount);
  };

  const playCurrentWeek = () => {
    if (currentWeek > (TEAMS.length - 1) * 2) return;

    // Must have exactly 11 starters
    if (mySquad.filter(p => p.isStarting).length !== 11) {
      alert('يجب اختيار 11 لاعب أساسي قبل لعب المباراة!');
      setActiveTab('SQUAD');
      return;
    }

    setIsSimulating(true);

    setTimeout(() => {
      const weeksMatches = schedule.filter(m => m.week === currentWeek);
      const updatedSchedule = [...schedule];
      let newStandings = [...standings];
      let myMatchData: Match | null = null;
      const starters = mySquad.filter(p => p.isStarting);

      weeksMatches.forEach(match => {
        let homeTeam = { ...TEAMS.find(t => t.id === match.homeTeamId)! };
        let awayTeam = { ...TEAMS.find(t => t.id === match.awayTeamId)! };
        
        // Override my team's rating with my squad's rating
        if (homeTeam.id === myTeamId) homeTeam.rating = myEffectiveRating;
        if (awayTeam.id === myTeamId) awayTeam.rating = myEffectiveRating;
        
        const { homeScore, awayScore } = simulateMatch(homeTeam, awayTeam);
        
        let matchEvents: MatchEvent[] = [];
        if (homeTeam.id === myTeamId || awayTeam.id === myTeamId) {
          let hTemp = homeScore;
          let aTemp = awayScore;
          const totalGoals = hTemp + aTemp;
          if (totalGoals > 0) {
            const minutes = Array.from({length: totalGoals}, () => Math.floor(Math.random() * 90) + 1).sort((a,b)=>a-b);
            minutes.forEach(min => {
              const isHomeEvent = hTemp > 0 && (aTemp === 0 || Math.random() > 0.5);
              const teamId = isHomeEvent ? homeTeam.id : awayTeam.id;
              if (isHomeEvent) hTemp--; else aTemp--;
              
              let pName = 'نجم الفريق';
              if (teamId === myTeamId) {
                const outfield = starters.filter(p => p.position !== 'GK').sort(() => Math.random() - 0.5);
                pName = outfield[0]?.name || 'لاعب وسط';
              }
              matchEvents.push({ minute: min, type: 'GOAL', teamId, playerDesc: pName });
            });
          }
        }

        const matchIndex = updatedSchedule.findIndex(m => m.id === match.id);
        updatedSchedule[matchIndex] = {
          ...updatedSchedule[matchIndex],
          homeScore,
          awayScore,
          events: matchEvents,
          played: true
        };

        newStandings = updateStandings(newStandings, updatedSchedule[matchIndex]);

        if (match.homeTeamId === myTeamId || match.awayTeamId === myTeamId) {
          myMatchData = updatedSchedule[matchIndex];
        }
      });

      setSchedule(updatedSchedule);
      setStandings(newStandings);
      setPlayedMatch(myMatchData);
      setIsSimulating(false);
      setGameState('MATCH');
    }, 2500); // Wait 2.5 seconds for dramatic effect
  };

  const continueToNextWeek = () => {
    setCurrentWeek(prev => prev + 1);
    setGameState('DASHBOARD');
  };

  const myTeam = TEAMS.find(t => t.id === myTeamId);
  const totalWeeks = (TEAMS.length - 1) * 2;
  const isSeasonOver = currentWeek > totalWeeks;

  return (
    <div className="min-h-screen manager-gradient text-slate-50 font-sans" dir="rtl" style={{
      backgroundImage: `linear-gradient(to bottom, rgba(9, 9, 11, 0.8), rgba(9, 9, 11, 0.95)), url('https://images.unsplash.com/photo-1605806616949-1e87b487bc2a?q=80&w=2000&auto=format&fit=crop')`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundAttachment: 'fixed',
    }}>
      {/* Header */}
      <header className="glass shadow-md">
        <div className="max-w-6xl mx-auto p-4 flex items-center justify-between">
          <div className="flex items-center gap-3 border-r-4 border-cyan-500 pr-3">
            <div>
              <h1 className="text-2xl font-black tracking-tighter text-cyan-400 uppercase font-fantasy text-shadow-sm glow">فانتسي ليج</h1>
              <p className="text-[10px] uppercase tracking-widest text-[#d4af37] font-bold">Lords of the Pitch</p>
            </div>
          </div>
          {myTeam && (
            <div className="flex items-center gap-3">
              <span className="text-slate-300">أسبوع {Math.min(currentWeek, totalWeeks)} / {totalWeeks}</span>
              <div 
                className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg shadow-inner"
                style={{ backgroundColor: myTeam.color, color: myTeam.secondaryColor, border: `2px solid ${myTeam.secondaryColor}` }}
              >
                {myTeam.name.charAt(0)}
              </div>
            </div>
          )}
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 py-8">
        {gameState === 'SETUP' && (
          <div className="space-y-8 animate-in fade-in zoom-in duration-500">
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-black tracking-tighter uppercase font-fantasy text-cyan-50 text-shadow">اختر مملكتك لتبدأ ملحمتك</h2>
              <p className="text-[10px] uppercase tracking-widest text-[#d4af37] font-bold">بين السحر والتكتيك، المجد ينتظر الأبطال</p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
              {TEAMS.map(team => (
                <button
                  key={team.id}
                  onClick={() => handleSelectTeam(team.id)}
                  className="glass p-6 rounded-2xl hover:border-cyan-500 hover:shadow-[0_0_15px_rgba(6,182,212,0.2)] transition-all group relative overflow-hidden flex flex-col items-center gap-4"
                >
                  <div 
                    className="w-20 h-20 rounded-full flex items-center justify-center font-bold text-3xl shadow-xl group-hover:scale-110 transition-transform"
                    style={{ backgroundColor: team.color, color: team.secondaryColor, border: `3px solid ${team.secondaryColor}` }}
                  >
                    {team.name.charAt(0)}
                  </div>
                  <div className="text-center">
                    <h3 className="font-bold text-lg">{team.name}</h3>
                    <div className="text-sm text-slate-400 flex items-center justify-center gap-1 mt-1">
                      <Shield className="w-4 h-4 text-[#d4af37]" />
                      <span>قوة السحرة: {team.rating}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {gameState === 'DASHBOARD' && myTeam && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Top Navigation Bar */}
            <div className="glass rounded-xl p-2 flex flex-col md:flex-row justify-between items-center gap-4">
              <nav className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
                <button 
                  onClick={() => setActiveTab('OVERVIEW')}
                  className={`px-6 py-2 rounded-lg font-bold text-sm transition-colors ${activeTab === 'OVERVIEW' ? 'bg-cyan-700 text-white shadow-lg shadow-cyan-700/20' : 'hover:bg-slate-800 text-slate-300'}`}
                >
                  نظرة عامة
                </button>
                <button 
                  onClick={() => setActiveTab('SQUAD')}
                  className={`px-6 py-2 rounded-lg font-bold text-sm transition-colors ${activeTab === 'SQUAD' ? 'bg-cyan-700 text-white shadow-lg shadow-cyan-700/20' : 'hover:bg-slate-800 text-slate-300'}`}
                >
                  التشكيلة
                </button>
                <button 
                  onClick={() => setActiveTab('TRANSFERS')}
                  className={`px-6 py-2 rounded-lg font-bold text-sm transition-colors ${activeTab === 'TRANSFERS' ? 'bg-cyan-700 text-white shadow-lg shadow-cyan-700/20' : 'hover:bg-slate-800 text-slate-300'}`}
                >
                  سوق الانتقالات
                </button>
              </nav>

              <div className="flex items-center gap-6 px-4">
                <div className="text-center">
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">قوة الفريق</div>
                  <div className="text-xl font-bold font-mono text-yellow-400">{myEffectiveRating}</div>
                </div>
                <div className="text-center md:border-r md:border-slate-700 md:pr-6">
                  <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">الميزانية</div>
                  <div className="text-xl font-bold font-mono text-green-400" dir="ltr">{formatMoney(budget)}</div>
                </div>
              </div>
            </div>

            {activeTab === 'OVERVIEW' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                {/* Left/Main Column */}
                <div className="lg:col-span-2 space-y-8">
                  {/* Next Match Card */}
                  {!isSeasonOver ? (
                    <div className="glass rounded-2xl p-6 relative overflow-hidden h-auto md:h-[300px] flex flex-col justify-center">
                      <div className="absolute top-0 right-[-20%] p-8 opacity-10 font-black text-[120px] leading-none uppercase">Match</div>
                      
                      <div className="relative z-10">
                        <div className="text-cyan-400 font-bold uppercase tracking-widest text-xs mb-8 text-center md:text-right">
                          معركة الأسبوع {currentWeek} - الساحة الكبرى
                        </div>

                      {(() => {
                        const nextMatch = schedule.find(m => m.week === currentWeek && (m.homeTeamId === myTeam.id || m.awayTeamId === myTeam.id));
                        if (!nextMatch) return null;
                        const homeTeam = TEAMS.find(t => t.id === nextMatch.homeTeamId)!;
                        const awayTeam = TEAMS.find(t => t.id === nextMatch.awayTeamId)!;
                        
                        return (
                          <div className="flex flex-col items-center gap-8 relative">
                            <div className="flex items-center justify-center w-full gap-8">
                              <div className="flex flex-col items-center gap-3 w-1/3">
                                <div className="w-24 h-24 rounded-full flex items-center justify-center font-bold text-4xl shadow-xl" style={{ backgroundColor: homeTeam.color, color: homeTeam.secondaryColor, border: `4px solid ${homeTeam.secondaryColor}` }}>
                                  {homeTeam.name.charAt(0)}
                                </div>
                                <span className="font-bold text-lg text-center">{homeTeam.name}</span>
                              </div>
                              
                              <div className="flex flex-col items-center justify-center">
                                <div className="text-4xl font-black text-white/20">VS</div>
                                <div className="mt-4 px-4 py-1 bg-slate-700/50 rounded-full text-[10px] font-bold uppercase tracking-widest hidden sm:block">Match Day</div>
                              </div>
                              
                              <div className="flex flex-col items-center gap-3 w-1/3">
                                <div className="w-24 h-24 rounded-full flex items-center justify-center font-bold text-4xl shadow-xl" style={{ backgroundColor: awayTeam.color, color: awayTeam.secondaryColor, border: `4px solid ${awayTeam.secondaryColor}` }}>
                                  {awayTeam.name.charAt(0)}
                                </div>
                                <span className="font-bold text-lg text-center">{awayTeam.name}</span>
                              </div>
                            </div>
                            
                            <div className="mt-12 flex justify-center space-x-4 space-x-reverse">
                              <button 
                                onClick={playCurrentWeek}
                                disabled={isSimulating}
                                className={`px-8 py-2 rounded-full font-bold text-sm transition-all shadow-lg mx-auto flex items-center justify-center gap-2 ${isSimulating ? 'bg-slate-700 text-slate-400 cursor-not-allowed' : 'bg-cyan-700 hover:bg-cyan-600 text-white neon-border shadow-cyan-700/20 active:scale-95'}`}
                              >
                                {isSimulating ? (
                                   <>
                                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                      جاري المحاكاة...
                                   </>
                                ) : (
                                  "لعب المباراة"
                                )}
                              </button>
                            </div>
                          </div>
                        );
                      })()}
                      </div>
                    </div>
                  ) : (
                    <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-12 text-center space-y-4">
                      <Trophy className="w-20 h-20 text-yellow-500 mx-auto" />
                      <h2 className="text-4xl font-bold text-white">انتهى الموسم!</h2>
                      <p className="text-xl text-green-200">تحقق من الترتيب النهائي في الجدول.</p>
                    </div>
                  )}

                  {/* Squad Preview */}
                  <div className="glass rounded-2xl p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-xs font-bold uppercase text-slate-500 tracking-widest flex items-center gap-2">
                        <Users className="text-cyan-500 w-4 h-4" />
                        أبرز نجوم الفريق
                      </h3>
                      <button onClick={() => setActiveTab('SQUAD')} className="text-[10px] text-cyan-400 hover:text-cyan-300 uppercase font-fantasy font-bold underline">تنظيم التشكيلة</button>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      {mySquad.filter(p => p.isStarting).slice(0, 4).map(player => (
                        <div key={player.id} className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl flex flex-col items-center justify-center text-center relative overflow-hidden group hover:border-cyan-500/50 transition-colors">
                          <div className="absolute top-0 right-0 w-8 h-8 bg-cyan-700/20 rounded-bl-xl"></div>
                          <div className="w-12 h-12 rounded-full overflow-hidden border border-slate-700 mb-2">
                            <img src={`https://api.dicebear.com/9.x/avataaars/svg?seed=${player.name}&backgroundColor=e2e8f0`} alt={player.name} className="w-full h-full object-cover" />
                          </div>
                          <div className="text-[10px] uppercase font-bold tracking-widest text-[#d4af37] mb-1">{player.position}</div>
                          <div className="font-bold text-sm truncate w-full">{player.name}</div>
                          <div className="text-sm text-yellow-500 font-bold mt-2 bg-yellow-500/10 px-2 py-1 rounded">
                            {player.rating}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right Column: Standings */}
                <div className="glass rounded-2xl flex flex-col overflow-hidden max-h-[800px] p-4">
                  <h3 className="text-xs font-bold uppercase text-slate-500 tracking-widest flex items-center gap-2 mb-4">
                    <Trophy className="text-[#d4af37] w-4 h-4" />
                    أبرز الفرق
                  </h3>
                  <div className="overflow-x-auto flex-1">
                    <table className="w-full text-right text-sm">
                      <thead className="border-b border-slate-800">
                        <tr>
                          <th className="p-2 text-[10px] uppercase font-bold tracking-widest text-slate-500 w-8 text-center">#</th>
                          <th className="p-2 text-[10px] uppercase font-bold tracking-widest text-slate-500">الفريق</th>
                          <th className="p-2 text-[10px] uppercase font-bold tracking-widest text-slate-500 text-center w-10">ل</th>
                          <th className="p-2 text-[10px] uppercase font-bold tracking-widest text-slate-500 text-center w-10">فارق</th>
                          <th className="p-2 text-[10px] uppercase font-bold tracking-widest text-slate-500 text-center w-12 text-white">ن</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-700/50">
                        {standings.map((row, idx) => {
                          const team = TEAMS.find(t => t.id === row.teamId)!;
                          const isMyTeam = team.id === myTeamId;
                          return (
                            <tr key={team.id} className={`${isMyTeam ? 'bg-blue-900/20' : 'hover:bg-slate-700/20'} transition-colors`}>
                              <td className="p-3 text-center text-slate-400">
                                {idx + 1}
                              </td>
                              <td className="p-3">
                                <div className="flex items-center gap-2">
                                  <div className="w-5 h-5 rounded-full" style={{ backgroundColor: team.color, border: `1px solid ${team.secondaryColor}` }} />
                                  <span className={isMyTeam ? 'font-bold text-cyan-400 text-shadow-sm' : 'font-medium'}>{team.name}</span>
                                </div>
                              </td>
                              <td className="p-3 text-center text-slate-400">{row.played}</td>
                              <td className="p-3 text-center text-slate-400" dir="ltr">{row.goalDifference > 0 ? `+${row.goalDifference}` : row.goalDifference}</td>
                              <td className="p-3 text-center font-bold text-white">{row.points}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'SQUAD' && (() => {
              const starters = mySquad.filter(p => p.isStarting);
              const bench = mySquad.filter(p => !p.isStarting);
              
              const gks = starters.filter(p => p.position === 'GK');
              const defs = starters.filter(p => p.position === 'DEF');
              const mids = starters.filter(p => p.position === 'MID');
              const fwds = starters.filter(p => p.position === 'FWD');

              const renderPitchPlayer = (player: MyPlayer) => (
                <div key={player.id} onClick={() => handlePlayerClick(player.id)} className={`flex flex-col items-center justify-center cursor-pointer transition-transform hover:scale-110 relative ${selectedSwapPlayer === player.id ? 'scale-110 z-10' : ''}`}>
                  <div className="relative">
                    <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full border-2 flex items-center justify-center shadow-lg overflow-hidden ${selectedSwapPlayer === player.id ? 'border-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.5)]' : 'border-slate-400'}`}>
                      <img src={`https://api.dicebear.com/9.x/avataaars/svg?seed=${player.name}&backgroundColor=e2e8f0`} alt={player.name} className="w-full h-full object-cover" />
                    </div>
                    <div className={`absolute -bottom-2 -right-2 w-6 h-6 rounded-full flex items-center justify-center font-bold text-[10px] border ${selectedSwapPlayer === player.id ? 'bg-yellow-400 text-black border-yellow-200' : 'bg-slate-800 text-yellow-400 border-slate-600'}`}>
                      {player.rating}
                    </div>
                  </div>
                  <div className={`mt-3 text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded shadow whitespace-nowrap max-w-[80px] truncate ${selectedSwapPlayer === player.id ? 'bg-yellow-400 text-slate-900' : 'bg-black/60 text-white'}`}>
                    {player.name}
                  </div>
                </div>
              );

              return (
              <div className="glass rounded-2xl p-6" style={{
                backgroundImage: `linear-gradient(to bottom, rgba(9, 9, 11, 0.8), rgba(9, 9, 11, 0.95)), url('https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=2000&auto=format&fit=crop')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}>
                <div className="flex flex-col md:flex-row items-center justify-between mb-6 gap-4">
                  <h3 className="text-xl font-bold uppercase tracking-widest text-slate-100 flex items-center gap-2">
                    <Shirt className="text-cyan-400 w-6 h-6" />
                    إدارة التشكيلة الأساسية
                  </h3>
                  <div className="flex flex-col sm:flex-row items-center gap-4 mt-4 md:mt-0">
                    <button
                      onClick={autoOptimizeSquad}
                      disabled={autoOrganizing}
                      className="px-4 py-2 bg-cyan-900/50 text-cyan-300 rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-cyan-800 transition-colors flex items-center gap-2 border border-cyan-500/30 disabled:opacity-50 w-full sm:w-auto font-fantasy"
                    >
                      {autoOrganizing ? (
                        <>
                           <div className="w-3 h-3 border-2 border-cyan-300 border-t-transparent rounded-full animate-spin"></div>
                           يحلل الذكاء الاصطناعي...
                        </>
                      ) : (
                         "⚙️ تنظيم ذكي (تلقائي)"
                      )}
                    </button>
                    <div className="text-sm font-bold text-slate-400 sm:border-r border-slate-700 sm:pr-4">
                      تبديل المكز: <span className="text-slate-300">اضغط على اللاعبين</span>
                    </div>
                  </div>
                </div>

                <div className="w-full max-w-2xl mx-auto bg-green-800 rounded-lg aspect-[3/4] sm:aspect-square md:aspect-[4/5] relative border-4 border-green-700 overflow-hidden shadow-2xl mb-8">
                   <div className="absolute top-0 left-1/4 right-1/4 h-1/6 border-x-2 border-b-2 border-white/30"></div>
                   <div className="absolute bottom-0 left-1/4 right-1/4 h-1/6 border-x-2 border-t-2 border-white/30"></div>
                   <div className="absolute top-1/2 left-0 right-0 h-0 border-t-2 border-white/30"></div>
                   <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full border-2 border-white/30"></div>

                   <div className="absolute inset-0 flex flex-col justify-between py-4 sm:py-8">
                      <div className="flex justify-evenly px-4 z-10">{fwds.map(renderPitchPlayer)}</div>
                      <div className="flex justify-evenly px-4 z-10">{mids.map(renderPitchPlayer)}</div>
                      <div className="flex justify-evenly px-4 z-10">{defs.map(renderPitchPlayer)}</div>
                      <div className="flex justify-center px-4 z-10">{gks.map(renderPitchPlayer)}</div>
                   </div>
                </div>

                <div className="mt-8 border-t border-slate-700 pt-6">
                  <h4 className="text-lg font-bold mb-4 text-slate-300">الاحتياط</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {bench.map(player => (
                        <div 
                          key={player.id}
                          onClick={() => handlePlayerClick(player.id)}
                          className={`p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition-colors ${selectedSwapPlayer === player.id ? 'bg-yellow-500/20 border-yellow-500 shadow-[0_0_10px_rgba(250,204,21,0.2)]' : 'bg-slate-900/50 border-slate-700 hover:border-slate-500'}`}
                        >
                          <div className="relative w-10 h-10">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center overflow-hidden border ${selectedSwapPlayer === player.id ? 'border-yellow-400' : 'border-slate-600 bg-slate-800'}`}>
                              <img src={`https://api.dicebear.com/9.x/avataaars/svg?seed=${player.name}&backgroundColor=e2e8f0`} alt={player.name} className="w-full h-full object-cover" />
                            </div>
                            <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center font-bold text-[8px] border ${selectedSwapPlayer === player.id ? 'bg-yellow-400 text-black border-yellow-200' : 'bg-slate-800 text-yellow-400 border-slate-600'}`}>
                              {player.rating}
                            </div>
                          </div>
                          <div>
                             <div className="font-bold text-sm">{player.name}</div>
                             <div className="text-[10px] text-slate-400 uppercase tracking-widest">{player.position}</div>
                          </div>
                        </div>
                    ))}
                  </div>
                </div>

              </div>
              );
            })()}

            {activeTab === 'TRANSFERS' && (
              <div className="glass rounded-2xl p-6" style={{
                backgroundImage: `linear-gradient(to bottom, rgba(9, 9, 11, 0.8), rgba(9, 9, 11, 0.95)), url('https://images.unsplash.com/photo-1507842217343-583bb7270b66?q=80&w=2000&auto=format&fit=crop')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}>
                <div className="flex flex-col md:flex-row items-center justify-between mb-6 gap-4">
                  <h3 className="text-xl font-bold uppercase tracking-widest text-[#d4af37] flex items-center gap-2 font-fantasy">
                    <DollarSign className="text-red-500 w-6 h-6" />
                    المزاد السحري
                  </h3>
                  <div className="text-sm font-bold text-slate-400 flex items-center gap-2">
                    الميزانية المتاحة: <span className="text-green-400 font-mono text-lg" dir="ltr">{formatMoney(budget)}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {marketPlayers.map(player => (
                    <div key={player.id} className="bg-black/60 border border-slate-800 p-5 rounded-2xl flex flex-col items-center text-center group hover:border-[#d946ef] hover:shadow-[0_0_15px_rgba(217,70,239,0.3)] transition-colors">
                      <div className="w-16 h-16 rounded-full bg-slate-800 border-2 border-slate-700 overflow-hidden flex items-center justify-center mb-3 shadow-inner">
                        <img src={`https://api.dicebear.com/9.x/avataaars/svg?seed=${player.name}&backgroundColor=e2e8f0`} alt={player.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="text-[10px] uppercase font-bold tracking-widest text-slate-500 mb-1">{player.position} | {player.age} عام</div>
                      <div className="font-bold text-lg mb-2">{player.name}</div>
                      
                      <div className="flex gap-4 w-full justify-center mb-4">
                        <div className="bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 px-3 py-1 rounded text-sm font-bold">
                          قوة: {player.rating}
                        </div>
                      </div>

                      <button 
                        onClick={() => buyPlayer(player)}
                        disabled={budget < player.price}
                        className={`w-full py-2 rounded-lg font-bold text-sm transition-colors ${budget >= player.price ? 'bg-gradient-to-r from-red-800 to-pink-700 hover:from-red-700 hover:to-pink-600 text-white shadow-lg shadow-red-500/20 font-fantasy track-widest' : 'bg-slate-800 text-slate-500 cursor-not-allowed'}`}
                      >
                        {budget >= player.price ? `شراء (${formatMoney(player.price)})` : `لا تملك (${formatMoney(player.price)})`}
                      </button>
                    </div>
                  ))}
                  
                  {marketPlayers.length === 0 && (
                    <div className="col-span-full py-12 text-center text-slate-500">
                      لا يوجد لاعبين متاحين في السوق حالياً.
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {gameState === 'MATCH' && playedMatch && myTeam && (
          <div className="max-w-2xl mx-auto mt-12 animate-in zoom-in-95 duration-300">
            <div className="glass rounded-2xl p-8 shadow-2xl relative overflow-hidden stat-card">
              <div className="absolute top-0 right-0 w-full h-1 bg-gradient-to-r from-cyan-500 to-teal-400" />
              
              <div className="text-center mb-8 text-[10px] font-bold tracking-widest uppercase text-slate-500">
                نتيجة المباراة - الأسبوع {currentWeek}
              </div>

              {(() => {
                const homeTeam = TEAMS.find(t => t.id === playedMatch.homeTeamId)!;
                const awayTeam = TEAMS.find(t => t.id === playedMatch.awayTeamId)!;
                const isHomeWin = playedMatch.homeScore! > playedMatch.awayScore!;
                const isAwayWin = playedMatch.awayScore! > playedMatch.homeScore!;
                const isDraw = playedMatch.homeScore === playedMatch.awayScore;
                
                let resultMessage = "تعادل مثير!";
                let resultColor = "text-yellow-400";
                
                if (playedMatch.homeTeamId === myTeamId) {
                  if (isHomeWin) { resultMessage = "انتصار رائع!"; resultColor = "text-green-400"; }
                  if (isAwayWin) { resultMessage = "هزيمة قاسية"; resultColor = "text-red-400"; }
                } else {
                  if (isAwayWin) { resultMessage = "انتصار رائع!"; resultColor = "text-green-400"; }
                  if (isHomeWin) { resultMessage = "هزيمة قاسية"; resultColor = "text-red-400"; }
                }

                return (
                  <div>
                    <h2 className={`text-3xl font-black text-center mb-10 ${resultColor}`}>{resultMessage}</h2>
                    
                    <div className="flex items-center justify-center gap-6 sm:gap-12 w-full">
                      <div className="flex flex-col items-center gap-4 flex-1">
                        <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full flex items-center justify-center font-bold text-4xl sm:text-6xl shadow-xl" style={{ backgroundColor: homeTeam.color, color: homeTeam.secondaryColor, border: `6px solid ${homeTeam.secondaryColor}` }}>
                          {homeTeam.name.charAt(0)}
                        </div>
                        <span className="font-bold text-xl text-center">{homeTeam.name}</span>
                      </div>
                      
                      <div className="flex flex-col items-center justify-center">
                        <div className="text-4xl font-black text-white/20 mb-4 uppercase">FT</div>
                        <div className="bg-slate-900/80 border border-slate-800 px-6 py-4 rounded-full flex items-center gap-4 text-5xl font-black tabular-nums shadow-inner neon-border">
                          <span>{playedMatch.homeScore}</span>
                          <span className="text-slate-600 text-3xl">-</span>
                          <span>{playedMatch.awayScore}</span>
                        </div>
                      </div>
                      
                      <div className="flex flex-col items-center gap-4 flex-1">
                        <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full flex items-center justify-center font-bold text-4xl sm:text-6xl shadow-xl" style={{ backgroundColor: awayTeam.color, color: awayTeam.secondaryColor, border: `6px solid ${awayTeam.secondaryColor}` }}>
                          {awayTeam.name.charAt(0)}
                        </div>
                        <span className="font-bold text-xl text-center">{awayTeam.name}</span>
                      </div>
                    </div>

                    {playedMatch.events && playedMatch.events.length > 0 && (
                      <div className="mt-8 bg-slate-900/50 border border-slate-800 rounded-xl p-4 max-w-sm mx-auto">
                        <h4 className="text-[10px] uppercase font-bold tracking-widest text-slate-500 mb-4 text-center">أحداث المباراة</h4>
                        <div className="space-y-3">
                          {playedMatch.events.map((event, i) => {
                            const isHomeEvent = event.teamId === homeTeam.id;
                            const tColor = isHomeEvent ? homeTeam.color : awayTeam.color;
                            return (
                              <div key={i} className="flex items-center gap-4 text-sm justify-between">
                                <div className={`flex items-center gap-2 ${isHomeEvent ? 'flex-row' : 'flex-row-reverse opacity-0'}`}>
                                   <div className="w-2 h-2 rounded-full" style={{backgroundColor: homeTeam.color}}></div>
                                   <span className="font-bold">{isHomeEvent ? event.playerDesc : ''}</span>
                                </div>
                                
                                <div className="text-[10px] font-bold text-slate-400 bg-slate-800 px-2 py-1 rounded-full whitespace-nowrap">
                                  {event.minute}'
                                </div>

                                <div className={`flex items-center gap-2 ${!isHomeEvent ? 'flex-row-reverse' : 'flex-row opacity-0'}`}>
                                   <div className="w-2 h-2 rounded-full" style={{backgroundColor: awayTeam.color}}></div>
                                   <span className="font-bold">{!isHomeEvent ? event.playerDesc : ''}</span>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}

              <div className="mt-12 flex justify-center">
                <button
                  onClick={continueToNextWeek}
                  className="bg-white text-black px-8 py-2 rounded-full font-bold text-sm tracking-widest uppercase transition-transform hover:scale-105 active:scale-95 shadow-lg"
                >
                  استمرار
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
