import { Team, Player } from './types';

export const TEAMS: Team[] = [
  { id: 't1', name: 'مدريد الملكي', rating: 88, color: '#ffffff', secondaryColor: '#1e3a8a' },
  { id: 't2', name: 'برشلونة الكتالوني', rating: 86, color: '#1e3a8a', secondaryColor: '#991b1b' },
  { id: 't3', name: 'مانشستر الأحمر', rating: 82, color: '#dc2626', secondaryColor: '#ffffff' },
  { id: 't4', name: 'مانشستر الأزرق', rating: 89, color: '#60a5fa', secondaryColor: '#ffffff' },
  { id: 't5', name: 'بافاريا ميونخ', rating: 88, color: '#b91c1c', secondaryColor: '#ffffff' },
  { id: 't6', name: 'باريس العاصمة', rating: 85, color: '#1e3a8a', secondaryColor: '#dc2626' },
  { id: 't7', name: 'يوفنتوس تورينو', rating: 81, color: '#000000', secondaryColor: '#ffffff' },
  { id: 't8', name: 'ميلان الأحمر', rating: 84, color: '#991b1b', secondaryColor: '#000000' }
];

export const DEFAULT_STARTING_SQUAD: Player[] = [
  { id: 's1', name: 'حارس شاب', position: 'GK', rating: 65, age: 20, price: 1000000 },
  { id: 's2', name: 'مدافع أيمن', position: 'DEF', rating: 67, age: 24, price: 1200000 },
  { id: 's3', name: 'قلب دفاع ١', position: 'DEF', rating: 68, age: 26, price: 1500000 },
  { id: 's4', name: 'قلب دفاع ٢', position: 'DEF', rating: 66, age: 22, price: 1100000 },
  { id: 's5', name: 'ظهير أيسر', position: 'DEF', rating: 64, age: 21, price: 900000 },
  { id: 's6', name: 'وسط ارتكاز', position: 'MID', rating: 69, age: 28, price: 1800000 },
  { id: 's7', name: 'وسط أيمن', position: 'MID', rating: 67, age: 25, price: 1300000 },
  { id: 's8', name: 'صانع ألعاب', position: 'MID', rating: 71, age: 23, price: 2500000 },
  { id: 's9', name: 'جناح أيمن', position: 'FWD', rating: 68, age: 20, price: 1400000 },
  { id: 's10', name: 'مهاجم صريح', position: 'FWD', rating: 70, age: 27, price: 2100000 },
  { id: 's11', name: 'جناح أيسر', position: 'FWD', rating: 65, age: 19, price: 1000000 },
  { id: 's12', name: 'حارس بديل', position: 'GK', rating: 60, age: 30, price: 500000 },
  { id: 's13', name: 'مدافع بديل', position: 'DEF', rating: 62, age: 25, price: 700000 },
  { id: 's14', name: 'وسط بديل', position: 'MID', rating: 63, age: 24, price: 800000 },
  { id: 's15', name: 'مهاجم بديل', position: 'FWD', rating: 64, age: 22, price: 950000 },
];

export const TRANSFER_MARKET_DB: Player[] = [
  { id: 'p1', name: 'روبرتو', position: 'GK', rating: 82, age: 28, price: 15000000 },
  { id: 'p2', name: 'كارلوس', position: 'DEF', rating: 85, age: 31, price: 20000000 },
  { id: 'p3', name: 'سيرجيو', position: 'DEF', rating: 80, age: 25, price: 12000000 },
  { id: 'p4', name: 'مالديني', position: 'DEF', rating: 88, age: 34, price: 25000000 },
  { id: 'p5', name: 'كافو', position: 'DEF', rating: 84, age: 29, price: 18000000 },
  { id: 'p6', name: 'زيدان', position: 'MID', rating: 89, age: 30, price: 35000000 },
  { id: 'p7', name: 'تشافي', position: 'MID', rating: 87, age: 26, price: 28000000 },
  { id: 'p8', name: 'إنييستا', position: 'MID', rating: 86, age: 24, price: 26000000 },
  { id: 'p9', name: 'ميسي', position: 'FWD', rating: 94, age: 22, price: 80000000 },
  { id: 'p10', name: 'رونالدو', position: 'FWD', rating: 93, age: 25, price: 75000000 },
  { id: 'p11', name: 'هنري', position: 'FWD', rating: 88, age: 28, price: 32000000 },
  { id: 'p12', name: 'بوفون', position: 'GK', rating: 86, age: 32, price: 22000000 },
  { id: 'p13', name: 'بيكهام', position: 'MID', rating: 83, age: 31, price: 16000000 },
  { id: 'p14', name: 'رونالدينيو', position: 'MID', rating: 91, age: 27, price: 50000000 },
  { id: 'p15', name: 'ديل بييرو', position: 'FWD', rating: 85, age: 29, price: 20000000 },
  { id: 'p16', name: 'نستا', position: 'DEF', rating: 87, age: 28, price: 24000000 },
  { id: 'p17', name: 'عوار', position: 'MID', rating: 79, age: 23, price: 9000000 },
  { id: 'p18', name: 'ديمبيلي', position: 'FWD', rating: 81, age: 24, price: 13000000 },
  { id: 'p19', name: 'فاردي', position: 'FWD', rating: 80, age: 30, price: 11000000 },
  { id: 'p20', name: 'أليسون', position: 'GK', rating: 88, age: 29, price: 30000000 },
];
