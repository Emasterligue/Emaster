import { Match, Team, LeagueStanding } from './types';

// Generate a double round-robin schedule
export function generateSchedule(teams: Team[]): Match[] {
  const matches: Match[] = [];
  const numTeams = teams.length;
  let matchIdCounter = 1;

  // Round robin algorithm
  const teamIds = teams.map(t => t.id);
  
  // First half of the season
  for (let week = 1; week < numTeams; week++) {
    for (let i = 0; i < numTeams / 2; i++) {
      const home = teamIds[i];
      const away = teamIds[numTeams - 1 - i];
      
      // Alternate home/away based on week to balance it
      const isEvenWeek = week % 2 === 0;
      
      matches.push({
        id: `m_${matchIdCounter++}`,
        week,
        homeTeamId: isEvenWeek ? away : home,
        awayTeamId: isEvenWeek ? home : away,
        homeScore: null,
        awayScore: null,
        played: false,
      });
    }
    // Rotate array: keep first element fixed, shift others right
    teamIds.splice(1, 0, teamIds.pop()!);
  }

  // Second half of the season (reverse fixtures)
  const firstHalfMatches = [...matches];
  const totalWeeks = (numTeams - 1) * 2;
  
  for (let match of firstHalfMatches) {
    matches.push({
      id: `m_${matchIdCounter++}`,
      week: match.week + numTeams - 1,
      homeTeamId: match.awayTeamId,
      awayTeamId: match.homeTeamId,
      homeScore: null,
      awayScore: null,
      played: false,
    });
  }

  return matches.sort((a, b) => a.week - b.week);
}

// Initialize standings table
export function initializeStandings(teams: Team[]): LeagueStanding[] {
  return teams.map(team => ({
    teamId: team.id,
    played: 0,
    won: 0,
    drawn: 0,
    lost: 0,
    goalsFor: 0,
    goalsAgainst: 0,
    goalDifference: 0,
    points: 0,
  }));
}

// Simulate a single match result based on team ratings
export function simulateMatch(homeTeam: Team, awayTeam: Team): { homeScore: number, awayScore: number } {
  // Home advantage (+2 rating)
  const homeAdvantage = 2;
  const ratingDiff = (homeTeam.rating + homeAdvantage) - awayTeam.rating;
  
  // Base expectation of goals
  // Higher rating diff = higher expected goals for stronger team, lower for weaker
  const expectedHomeGoals = Math.max(0.5, 1.5 + (ratingDiff * 0.05));
  const expectedAwayGoals = Math.max(0.5, 1.2 - (ratingDiff * 0.05));

  // Poisson-like randomization (simplified)
  const getGoals = (lambda: number) => {
    let L = Math.exp(-lambda);
    let p = 1.0;
    let k = 0;
    do {
      k++;
      p *= Math.random();
    } while (p > L);
    return k - 1;
  };

  return {
    homeScore: getGoals(expectedHomeGoals),
    awayScore: getGoals(expectedAwayGoals),
  };
}

// Update standings with new match results
export function updateStandings(
  standings: LeagueStanding[],
  match: Match
): LeagueStanding[] {
  if (!match.played || match.homeScore === null || match.awayScore === null) return standings;

  const newStandings = standings.map(s => ({ ...s }));
  const homeStat = newStandings.find(s => s.teamId === match.homeTeamId)!;
  const awayStat = newStandings.find(s => s.teamId === match.awayTeamId)!;

  // Update goals
  homeStat.goalsFor += match.homeScore;
  homeStat.goalsAgainst += match.awayScore;
  homeStat.goalDifference = homeStat.goalsFor - homeStat.goalsAgainst;
  
  awayStat.goalsFor += match.awayScore;
  awayStat.goalsAgainst += match.homeScore;
  awayStat.goalDifference = awayStat.goalsFor - awayStat.goalsAgainst;

  // Update played
  homeStat.played += 1;
  awayStat.played += 1;

  // Update W/D/L and points
  if (match.homeScore > match.awayScore) {
    homeStat.won += 1;
    homeStat.points += 3;
    awayStat.lost += 1;
  } else if (match.homeScore < match.awayScore) {
    awayStat.won += 1;
    awayStat.points += 3;
    homeStat.lost += 1;
  } else {
    homeStat.drawn += 1;
    homeStat.points += 1;
    awayStat.drawn += 1;
    awayStat.points += 1;
  }

  // Sort: Points DESC, GoalDiff DESC, GoalsFor DESC
  return newStandings.sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.goalDifference !== a.goalDifference) return b.goalDifference - a.goalDifference;
    return b.goalsFor - a.goalsFor;
  });
}
